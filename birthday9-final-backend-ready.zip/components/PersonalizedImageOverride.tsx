"use client";

import { useEffect } from "react";

type Gender = "girl" | "boy";
type CardData = { gender?: Gender; images?: string[]; image?: string };
const KEY = "birthday-card-v3";
const OLD_KEY = "birthday-card-v2";

function bytesToBase64Bytes(value: string) {
  const base = value.replace(/-/g, "+").replace(/_/g, "/") + "===".slice((value.length + 3) % 4);
  const binary = atob(base);
  return Uint8Array.from(binary, (c) => c.charCodeAt(0));
}

async function decode(value: string): Promise<CardData | null> {
  try {
    const [kind, payload] = value.split(".", 2);
    const bytes = bytesToBase64Bytes(payload || value);
    let raw = bytes;
    if (kind === "g" && "DecompressionStream" in window) {
      const stream = new DecompressionStream("gzip");
      const writer = stream.writable.getWriter(); writer.write(bytes); writer.close();
      raw = new Uint8Array(await new Response(stream.readable).arrayBuffer());
    }
    return JSON.parse(new TextDecoder().decode(raw));
  } catch { return null; }
}

async function getCard(): Promise<CardData | null> {
  try {
    const params = new URLSearchParams(window.location.search);
    const compact = params.get("c");
    if (compact) return await decode(compact);
    const hash = new URLSearchParams(window.location.hash.slice(1));
    const legacy = hash.get("card");
    if (legacy) return await decode(legacy);
    return JSON.parse(localStorage.getItem(KEY) || localStorage.getItem(OLD_KEY) || "null");
  } catch { return null; }
}

function girlIndex(value: string): number {
  if (!value) return -1;
  try {
    const decoded = decodeURIComponent(value);
    const m = decoded.match(/\/ref\/girl(\d*)\.jpg(?:[?#&]|$)/i);
    if (!m) return -1;
    return m[1] ? Number(m[1]) : 0;
  } catch { return -1; }
}

export default function PersonalizedImageOverride() {
  useEffect(() => {
    let card: CardData | null = null;
    let photos: string[] = [];
    let gender: Gender = "girl";

    const refresh = async () => {
      card = await getCard();
      photos = Array.isArray(card?.images) ? card!.images! : card?.image ? [card.image] : [];
      gender = card?.gender === "boy" ? "boy" : "girl";
      replaceImages();
    };

    const replaceImages = () => {
      document.querySelectorAll<HTMLImageElement>("img").forEach((img) => {
        const original = img.dataset.birthdayOriginalSrc || img.getAttribute("src") || "";
        if (!img.dataset.birthdayOriginalSrc && girlIndex(original) >= 0) img.dataset.birthdayOriginalSrc = original;
        const src = img.getAttribute("src") || "";
        const srcset = img.getAttribute("srcset") || "";
        const dataSrc = img.getAttribute("data-src") || "";
        const index = Math.max(girlIndex(original), girlIndex(src), girlIndex(srcset), girlIndex(dataSrc));
        if (index < 0) return;
        const photo = photos[index] || photos[0];
        const replacement = photo || (gender === "boy" ? `/ref/boy/boy${index + 1}.svg` : "");
        if (!replacement) return;
        img.dataset.birthdayPersonalized = "true";
        img.setAttribute("src", replacement);
        img.setAttribute("srcset", replacement);
        img.removeAttribute("data-src"); img.removeAttribute("data-srcset");
      });
    };

    refresh();
    const observer = new MutationObserver(() => replaceImages());
    observer.observe(document.body, { subtree: true, childList: true, attributes: true, attributeFilter: ["src", "srcset", "data-src", "data-srcset"] });
    const onChange = () => { document.querySelectorAll<HTMLImageElement>('img[data-birthday-personalized="true"]').forEach((img) => delete img.dataset.birthdayPersonalized); refresh(); };
    window.addEventListener("storage", onChange); window.addEventListener("birthday-personalization-changed", onChange); window.addEventListener("hashchange", onChange);
    return () => { observer.disconnect(); window.removeEventListener("storage", onChange); window.removeEventListener("birthday-personalization-changed", onChange); window.removeEventListener("hashchange", onChange); };
  }, []);
  return null;
}
