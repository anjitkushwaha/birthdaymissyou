"use client";

import React, { useEffect, useState } from "react";
import MarqueeAlongSvgPath from "../LineCmp";

const path =
  "M1 209.434C58.5872 255.935 387.926 325.938 482.583 209.434C600.905 63.8051 525.516 -43.2211 427.332 19.9613C329.149 83.1436 352.902 242.723 515.041 267.302C644.752 286.966 943.56 181.94 995 156.5";

const KEY = "birthday-card-v2";
const DEFAULT_NAME = "Sweety";
const DEFAULT_MESSAGE = "May this year bring you closer to everything you're chasing.";

type BirthdayData = {
  name: string;
  date: string;
  message: string;
};

function decodeCard(encoded: string): BirthdayData | null {
  try {
    const base = encoded.replace(/-/g, "+").replace(/_/g, "/") + "===".slice((encoded.length + 3) % 4);
    const binary = atob(base);
    const bytes = Uint8Array.from(binary, (c) => c.charCodeAt(0));
    const json = new TextDecoder().decode(bytes);
    const parsed = JSON.parse(json);
    return {
      name: typeof parsed?.name === "string" ? parsed.name : "",
      date: typeof parsed?.date === "string" ? parsed.date : "",
      message: typeof parsed?.message === "string" ? parsed.message : "",
    };
  } catch {
    return null;
  }
}

function readBirthdayData(): BirthdayData {
  if (typeof window === "undefined") {
    return { name: "", date: "", message: "" };
  }

  try {
    const hash = new URLSearchParams(window.location.hash.slice(1));
    const encoded = hash.get("card");
    if (encoded) {
      const fromHash = decodeCard(encoded);
      if (fromHash) return fromHash;
    }
  } catch {
    // Fall back to localStorage.
  }

  try {
    const raw = localStorage.getItem(KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      return {
        name: typeof parsed?.name === "string" ? parsed.name : "",
        date: typeof parsed?.date === "string" ? parsed.date : "",
        message: typeof parsed?.message === "string" ? parsed.message : "",
      };
    }
  } catch {
    // Keep defaults.
  }

  return { name: "", date: "", message: "" };
}

function formatDate(dateValue: string) {
  if (!dateValue) return { short: "AUG 02", year: "" };
  const match = /^(\d{4})-(\d{2})-(\d{2})$/.exec(dateValue);
  if (!match) return { short: dateValue, year: "" };
  const year = Number(match[1]);
  const month = Number(match[2]);
  const day = Number(match[3]);
  const date = new Date(year, month - 1, day);
  if (date.getFullYear() !== year || date.getMonth() !== month - 1 || date.getDate() !== day) {
    return { short: dateValue, year: "" };
  }
  return {
    short: date.toLocaleDateString("en-US", { month: "short", day: "2-digit" }).toUpperCase(),
    year: String(year),
  };
}

// Local photos from /public/ref — resolve to /ref/*.jpg at runtime.
// Keep this list in exactly the same order as the 12 upload slots:
// Image 1 = girl.jpg, Image 2 = girl1.jpg, ... Image 12 = girl11.jpg.
const imgs = Array.from({ length: 12 }, (_, index) => ({
  src: index === 0 ? "/ref/girl.jpg" : `/ref/girl${index}.jpg`,
}));

export const HeroSection = () => {
  const [birthday, setBirthday] = useState<BirthdayData>({ name: "", date: "", message: "" });

  useEffect(() => {
    const refresh = () => setBirthday(readBirthdayData());
    refresh();
    window.addEventListener("birthday-personalization-changed", refresh);
    window.addEventListener("hashchange", refresh);
    window.addEventListener("storage", refresh);
    return () => {
      window.removeEventListener("birthday-personalization-changed", refresh);
      window.removeEventListener("hashchange", refresh);
      window.removeEventListener("storage", refresh);
    };
  }, []);

  const name = birthday.name.trim() || DEFAULT_NAME;
  const message = birthday.message.trim() || DEFAULT_MESSAGE;
  const date = formatDate(birthday.date);

  return (
    <section className="relative overflow-hidden flex min-h-screen w-full flex-col overflow-x-hidden bg-[#FAFAF7]">
      <style jsx global>{`
        @import url("https://fonts.googleapis.com/css2?family=Bricolage+Grotesque:opsz,wght@12..96,300..800&family=Work+Sans:wght@400;500&family=JetBrains+Mono:wght@400;500&display=swap");

        .hero-display {
          font-family: "Bricolage Grotesque", sans-serif;
        }
        .hero-body {
          font-family: "Work Sans", sans-serif;
        }
        .hero-mono {
          font-family: "JetBrains Mono", monospace;
        }
      `}</style>

      {/* Top row: personalized birthday date, including the selected year. */}
      <div className="hero-mono flex items-center justify-between px-8 pt-8 text-[11px] uppercase tracking-[0.25em] text-[#8A8A80] sm:px-14">
        <span>
          {date.short}
          {date.year ? ` · ${date.year}` : ""}
        </span>
      </div>

      {/* Headline — original layout preserved; only the personalized name is dynamic. */}
      <div className="px-8 pt-16 sm:px-14 sm:pt-20">
        <h1 className="hero-display text-[15vw] leading-[0.86] tracking-tight text-[#14140F] sm:text-7xl lg:text-8xl">
          <span className="font-light">Happy</span>
          <br />
          <span className="font-bold">Birthday</span>
          <br />
          <span className="font-bold text-amber-500 break-words">{name}</span>
        </h1>
        <div className="mt-6 h-px w-16 bg-[#9C7A3F]" />
        <p className="hero-body mt-6 max-w-sm text-base leading-relaxed text-[#4A4A42]">
          {message}
        </p>
      </div>

      {/* The trail — unchanged original effect. */}
      <div className="absolute top-50 left-1/2 mt-0 w-screen -rotate-10 -translate-x-1/2">
        <MarqueeAlongSvgPath
          path={path}
          viewBox="0 0 996 330"
          width="100%"
          height="300"
          baseVelocity={5}
          slowdownOnHover={true}
          draggable={true}
          repeat={2}
          dragSensitivity={0.08}
          dragVelocityDecay={0.98}
          slowDownFactor={0.05}
          slowDownSpringConfig={{ damping: 60, stiffness: 300 }}
          className="w-full h-full"
          responsive
          grabCursor
        >
          {imgs.map((img, i) => (
            <div
              key={i}
              className="h-14 w-14 overflow-hidden border border-[#14140F]/15 bg-[#14140F]/5 transition-transform duration-300 ease-out hover:scale-105"
            >
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img
                src={img.src}
                alt={`Memory ${i + 1}`}
                className="h-full w-full object-cover grayscale transition-[filter] duration-300 ease-out hover:grayscale-0"
                draggable={false}
              />
            </div>
          ))}
        </MarqueeAlongSvgPath>
      </div>

      <div className="mt-auto flex items-center justify-between px-8 pb-8 sm:px-14">
        <div className="h-px flex-1 bg-[#14140F]/10" />
        <span className="hero-mono px-4 text-[10px] uppercase tracking-[0.25em] text-[#8A8A80]">
          Made for you
        </span>
      </div>
    </section>
  );
};
