import { NextResponse } from "next/server";

export async function POST(request: Request) {
  try {
    const keyId = process.env.RAZORPAY_KEY_ID || "rzp_test_Tjbo0NUQh1eAiF";
    const keySecret = process.env.RAZORPAY_KEY_SECRET;
    if (!keyId || !keySecret) return NextResponse.json({ error: "Secure payment is not configured. Add Razorpay keys on the server." }, { status: 503 });
    const body = await request.json().catch(() => ({}));
    if (body?.amount !== 4900) return NextResponse.json({ error: "Invalid payment amount." }, { status: 400 });
    const auth = Buffer.from(`${keyId}:${keySecret}`).toString("base64");
    const response = await fetch("https://api.razorpay.com/v1/orders", {
      method: "POST", headers: { Authorization: `Basic ${auth}`, "Content-Type": "application/json" },
      body: JSON.stringify({ amount: 4900, currency: "INR", receipt: `birthday_${Date.now()}`, payment_capture: 1 }), cache: "no-store",
    });
    const order = await response.json();
    if (!response.ok || !order?.id) return NextResponse.json({ error: "Could not create payment order." }, { status: 502 });
    return NextResponse.json({ id: order.id, amount: order.amount, keyId });
  } catch { return NextResponse.json({ error: "Payment service unavailable." }, { status: 502 }); }
}
