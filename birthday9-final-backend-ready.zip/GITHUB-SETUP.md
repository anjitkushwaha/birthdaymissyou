# GitHub + secure payment setup

## 1. Upload this folder to GitHub
Create a new repository, then upload the **contents of this folder** (not the outer ZIP folder). GitHub's browser upload supports files up to 25 MiB each; this project is split into normal source/assets files.

Do **not** upload `.env` or real API keys.

## 2. Payment backend
This project includes secure server routes:
- `POST /api/payment/create-order` — creates a fixed ₹49 Razorpay order on the server.
- `POST /api/payment/verify` — verifies the Razorpay checkout signature on the server before the link is created.

The QR and UPI ID shown in the manual-payment fallback remain fixed as:
`8521536869@ibl`

Manual UTR entry is intentionally not treated as automatic bank verification.

## 3. Get API keys
Create/activate a Razorpay merchant account and get the Key ID + Key Secret from the Razorpay Dashboard. Start with test keys while testing.

## 4. Deploy
Deploy the GitHub repository to Vercel (recommended for this Next.js app) or another Next.js-capable host.

Add these Environment Variables in the hosting dashboard:
- `RAZORPAY_KEY_ID`
- `RAZORPAY_KEY_SECRET`
- `NEXT_PUBLIC_RAZORPAY_KEY_ID`

Use the same public Key ID for the last variable. Keep `RAZORPAY_KEY_SECRET` server-only.

After adding/changing environment variables, redeploy.

## 5. Test before live payment
Use Razorpay test mode first. Confirm:
1. Details are filled.
2. ₹49 secure checkout opens.
3. Successful payment returns to the site.
4. `/api/payment/verify` returns `verified: true`.
5. Only then is the personalized link generated.
6. Shortening is optional; if the shortener is unavailable, the full personalized link is still created.

## 6. Security notes
Never put the Razorpay secret in client code, GitHub, or `.env.local` committed to the repository. Keep secrets in the hosting provider's environment-variable settings.
