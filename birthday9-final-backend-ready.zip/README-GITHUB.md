# Birthday Card — GitHub Ready

This is the complete Next.js project. It keeps the existing Girl design, Boy option, personalization, photos, QR/UPI fallback and short-link behavior.

## Secure ₹49 payment
The project contains server-side Razorpay endpoints. The browser never receives the Razorpay secret.

- `POST /api/payment/create-order` — server creates exactly ₹49 order.
- `POST /api/payment/verify` — verifies checkout signature and confirms the captured ₹49 payment on Razorpay before link creation.
- Manual QR/UPI fallback remains visible with fixed UPI `8521536869@ibl`, but a manually entered UTR is **not** treated as automatic bank verification.

## GitHub
1. Create an empty repository.
2. Extract this ZIP.
3. Upload the **contents** of the extracted folder to the repository root.
4. Do not upload `.env` files or API secrets.

GitHub's browser upload has a 25 MiB per-file limit, so this project is already arranged as individual source/assets files.

## Local setup
```bash
npm install
cp .env.example .env.local
npm run dev
```

For secure payment, fill the Razorpay variables in `.env.local` with test credentials first.

## Deploy
Vercel is recommended for this Next.js app. Connect the GitHub repository and add these Environment Variables in the hosting dashboard:

```text
RAZORPAY_KEY_ID=...
RAZORPAY_KEY_SECRET=...
NEXT_PUBLIC_RAZORPAY_KEY_ID=...
```

Use the same public Key ID for `NEXT_PUBLIC_RAZORPAY_KEY_ID`. Keep `RAZORPAY_KEY_SECRET` server-only. Redeploy after changing variables.

## Production payment
Before taking real payments, activate the payment account and configure the gateway according to its merchant/KYC requirements. Test the complete flow first. Never put API secrets in GitHub.

## Current Razorpay Test Key
The public Razorpay Test Key ID `rzp_test_Tjbo0NUQh1eAiF` is preconfigured in this build. The Secret Key is intentionally NOT included. Add only `RAZORPAY_KEY_SECRET` in Vercel Environment Variables, then redeploy.
